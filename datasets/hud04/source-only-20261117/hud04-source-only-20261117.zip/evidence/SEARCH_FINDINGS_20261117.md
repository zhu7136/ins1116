# Official Project Instinct motion-source search — 2026-11-17

## Scope and execution boundary

- Searched recursive default-branch trees and 52 text documents across 11 repositories; snapshots are in per-repository `tree.json`. Scanned releases for all 11, and full first-page issue/PR lists (<100 entries each) of InstinctLab, deep-whole-body-parkour, omniretargeting, robot-motion-editor and InstinctMJ. Issue comments, all historical branches and all commit history were NOT exhaustively searched. Organization issue search returned 422, not zero results; direct repository lists were used instead.
- Anonymous public Google Drive downloads only; GitHub token only sent to api.github.com. No source code execution, policy/checkpoint deserialization, GPU or Flux calls, solver, retargeting, PPO, repository mutation or publication. Original input files unchanged.

## 1. Exact official source binding found

Official project-page snapshot:
https://github.com/project-instinct/deep-whole-body-parkour/blob/abc7e1917a7e25e5ec931817a24ac3d704e0f823/index.html#L185-L204

Its data label is **Data (motion reference for G1 29dof torso base)**, distinct from the adjacent checkpoints link. The data URL is:
https://drive.google.com/drive/folders/1dpSYHVhP1kFdBK5ixh_f_3g0vcbyC08f

This folder is titled Deep-Wholebody-Parkour_Dataset and contains six scenario folders plus a root metadata.yaml.

- With-wall folder: https://drive.google.com/drive/folders/1L421F7m2FEfrkb1b-gu01hhNj0Y1Ufan
- No-wall folder: https://drive.google.com/drive/folders/1bRSMh3DO8ZO-9vraTAjNLyaDnbXT2M80

Downloaded root metadata and every listed non-folder file from those two scenario folders: 17 files total. All **seven** files in the with-wall scenario directory match the seven user-provided originals by full SHA-256: four NPZs, two YAMLs and the STL. This is content-identity evidence, not a filename inference.

Step1 SHA-256:
`56158e8679580910ccff375963d025b138636acfe70f5b1f88381837209b2056`

All four motion files are also byte-identical between the with-wall and no-wall directories. Terrain and selection metadata differ. Therefore do NOT substitute the no-wall geometry to pass the with-wall reference or treat equal motion hashes as equal contact situations.

The root YAML assigns with-wall Step1 to terrain_id 2 and `50cm_kneeClimbStep/50cmboxes_19_36_49.stl`, and no-wall Step1 to terrain_id 4 and `50cm_kneeClimbStep_noWall/50cmboxes_noWall.stl`. Each scenario-local Step1 YAML instead uses terrain_id 0. Terrain IDs are local to their manifest; do not interchange root/local indices.

Verified schemas (allow_pickle=False): jumpsit2 967 frames, Step1 997, rollVault11 942, superheroLanding 522; every file declares 90 Hz (superheroLanding scalar stored as float64, others int64). These are existing G1 source motions, not newly accepted HUD04 references.

## 2. Released-data interpretation has stronger evidence

The official release explicitly declares torso-base. The pinned actual perceptive task uses `G1_29DOF_TORSOBASE_POPSICLE_CFG`, reference prim torso_link, and `g1_29dof_torsobase_popsicle.urdf`, not the older simplified asset.

Checked three restored source files against Git blob identities in InstinctLab commit `de6b92f01eb155d51f30e8ed1ea7aecd2eb1f057`: actual perceptive config, `assets/unitree_g1.py`, `motion_files/amass_motion.py`. All three match exactly. The NPZ reader directly consumes base_pos_w and base_quat_w (no xyzw-to-wxyz permutation), then uses IsaacLab combine_frame_transforms.

Independently downloaded and Git-blob-verified IsaacLab math.py at the actual README pin `f73c33173801f5f8afea4142482e47b7710c2b75`; combine_frame_transforms explicitly expects (w,x,y,z). Blob SHA-1: `96314abfbd09be50e9cd9e606c4be57f5bcd0ffc`.

This establishes the **intended official released-data interface** as torso-base with wxyz consumer semantics, and directly binds the released dataset to the user's exact NPZ bytes. It does NOT reconstruct the actual unobserved exporter invocation, prove no prior editing, identify every original world-unit conversion, or prove reference physical/contact validity. No coordinate setting, source data, solver gate or acceptance manifest was changed this turn; prior four-hypothesis probe outputs remain historical, not acceptance evidence.

Evidence: `motion_source_comparison.json`, `source_interface_chain.json`, `official_drive/download_manifest.json`, pinned project page and pinned source files.

## 3. Additional official training dataset release located, not downloaded

https://github.com/project-instinct/InstinctMJ/releases/tag/supermimic-v0.1

The release lists `20251116_50cm_kneeClimbStep1.zip` (2,694,926 bytes) plus SHA256SUMS and separate G1 policy/world-model files. The release text describes ten G1 motions on five terrains. This is a separate release description: do not assume its contents or terrain indices equal the Drive root's six-terrain manifest.

Asset URL:
https://github.com/project-instinct/InstinctMJ/releases/download/supermimic-v0.1/20251116_50cm_kneeClimbStep1.zip

The first checksum download redirected to release-assets.githubusercontent.com and failed during connection establishment. Explicitly verified redirect host with redirects disabled. No release asset, checksum, archive contents, success statistics or checkpoint was independently verified; the release's reported training/evaluation numbers are author claims and are NOT HUD04 results. Need network permission for release-assets.githubusercontent.com to check ONLY this small dataset ZIP and checksums; no need to download or load policy/world-model PT files.

## 4. Other useful, non-substitutable evidence

- omniretargeting contains actual AMASS sample NPZs, Nokov diveroll4 BVH, OMOMO example descriptions and a G1 popsicle model. Useful adapter examples, not evidence that any sample equals Step1.
- robot_trajectory_editor agents/CONTACT_FREE.md discusses Nokov jumpsit2 and failed feasibility tests. Those logs describe failures and must not be recast as accepted references or our own results.
- No exact original Step1 PKL/export invocation or authoritative hand/foot/knee support annotations were recovered within the searched snapshots and downloaded folders. This bounded negative result does not assert absence from every branch, private system or release asset.

## Next work

1. Verify the newly found dataset ZIP/checksums after granting its redirect host, comparing hashes/schema/metadata without executing anything.
2. Write an explicit source-interface contract separating official torso/wxyz consumption evidence from still-missing exporter/unit history. Do not require an original PKL as the sole possible form of interface evidence.
3. Use that evidence to deliberately review coordinate candidates, actual processed with-wall terrain and support windows; retain remaining uncertainty instead of selecting via minimum vertical gap.
4. Only after reference/solver gates are met consider bounded retargeting; accepted_reference=false and training_ready=false remain unchanged.